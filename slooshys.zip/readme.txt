SLOOSHYS
======

Team Name: Slooshys

Team Member Names:
Qaswar Al-Hindawi - 300193051
Marouane Bouzzit - 300206399
Hiba Idrissi- 300200222
Adnane Bouchama - 300177651
Yara Elmasry - 300157512
Ayman Bennaceur - 300203212








Product Name: Slooshys Slush Machine & Sloosh Mix

Description:
Create a website that sells a slushy machine with the option of many flavors to choose from. 
The site will be based on a monthly subscription and the customer would receive a package every month with the flavor capsules that they have chosen. 
In addition to that, we could sell our product containers and cups. ( Company name: Slooshys)    

Standard Option: Regular Slooshys slushy mix

Protein Option: Include an amount of protein in the slushy mix


Sugar-Free Option: No sugar in the slushy mix to accommodate diabetic people and people who are trying to go on a diet.

Flash Option:  A combination of the slushy mix and an energy drink.


=======

